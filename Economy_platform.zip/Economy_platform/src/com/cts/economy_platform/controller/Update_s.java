
package com.cts.economy_platform.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.economy_platform.util.dataconn;


@WebServlet("/Update_s.do")
public class Update_s extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update_s() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		HttpSession hts=request.getSession();
		Connection con = dataconn.connect();
		PreparedStatement ps = null;
		String id=(String) request.getParameter("Product_UserId");
		String vid=(String) request.getParameter("Vendor_UserId");
		
		int price=Integer.parseInt(request.getParameter("price"));
		String t2=(String) request.getParameter("t2");
	
		String des=(String) request.getParameter("des");

		System.out.println(id);
		System.out.println(vid);
		


		String query1 = "update service_details set type2=?,price=?,description=? where product_id=?" ;
        try {
			ps=con.prepareStatement(query1);
	
			ps.setString(1,t2);
			ps.setInt(2,price);
			ps.setString(3,des);
			ps.setString(4,id);
	
		/*ps.setString(1,);
		ps.setString(2, t);
		ps.setString(3, t1);
		ps.setInt(4, l);
		ps.setInt(5, b);
		ps.setInt(6, h);
		ps.setString(7,c);
		ps.setString(8, m);
		ps.setString(9,br);
		ps.setInt(10, p);
		ps.setString(11,de);*/
		//ps.setString(12,id);
	
			ps.executeUpdate();
			
			
			RequestDispatcher rd = request.getRequestDispatcher("vendor_main.jsp?up=Your Details are Updated!!!");
            rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
